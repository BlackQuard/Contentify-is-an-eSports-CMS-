<?php

ModuleRoute::context('Example');

ModuleRoute::get('example', 'ExampleController@getIndex');