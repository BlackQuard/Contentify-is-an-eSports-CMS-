<?php

namespace App\Modules\Example\Http\Controllers;

use BackController;

class AdminExampleController extends BackController
{

}
