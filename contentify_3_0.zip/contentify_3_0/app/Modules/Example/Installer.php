<?php

namespace App\Modules\Example;

use ModuleInstaller;

class Installer extends ModuleInstaller
{

    /**
     * {@inheritDoc}
     */
    public function execute()
    {

    }
}
