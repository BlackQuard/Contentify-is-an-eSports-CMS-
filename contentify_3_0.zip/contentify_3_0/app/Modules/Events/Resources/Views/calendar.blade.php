<h1 class="page-title">{{ trans('app.calendar') }}</h1>

@widget('Events::Calendar', compact('year', 'month'))