<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'written_by'         => 'Comentario escrito por',
    'written_on'         => 'el', // Date
    'written_at'         => 'a las', // Time
    'write'              => 'Escribe un comentario:',
    'login_info'         => 'Para escribir un comentario, :0 o :1.',

    /* 
     * Widget
     */
    'latest_comments'   => 'Últimos comentarios',

];
