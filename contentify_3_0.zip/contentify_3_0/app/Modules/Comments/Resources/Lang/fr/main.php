<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'written_by'         => 'Ecrit par',
    'written_on'         => 'le', // Date
    'written_at'         => 'à', // Time
    'write'              => 'Ecrire un commentaire:',
    'login_info'         => 'Pour écrire un commentaire, :0 ou :1.',

    /* 
     * Widget
     */
    'latest_comments'   => 'Derniers Commentaires',

];
