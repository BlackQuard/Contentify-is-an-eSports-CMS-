<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'written_by'         => 'Comment written by',
    'written_on'         => 'on', // Date
    'written_at'         => 'at', // Time
    'write'              => 'Write a comment:',
    'login_info'         => 'To write a comment, :0 or :1.',

    /* 
     * Widget
     */
    'latest_comments'   => 'Latest Comments',

];
