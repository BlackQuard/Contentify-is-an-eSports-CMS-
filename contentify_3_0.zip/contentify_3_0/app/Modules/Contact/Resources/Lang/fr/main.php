<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */

    'message_sent'  => 'Merci! Votre message a été envoyé.',
    'application'   => 'Candidature', // If the user applies for a role in one of the teams

    /*
     * Email
     */
    'mail_title'    => 'Nouveau message',
    'mail_created'  => 'créer un nouveau message.',
    'mail_link'     => 'Cliquez ici pour lire le message.',

];
