<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */

    'message_sent'  => '¡Gracias! Tu mensaje ha sido enviado.',
    'application'   => 'Solicitud', // If the user applies for a role in one of the teams

    /*
     * Email
     */
    'mail_title'    => 'Nuevo mensaje de contacto',
    'mail_created'  => 'creado un nuevo mensaje de contacto.',
    'mail_link'     => 'Haz click aquí para ver el mensaje.',

];
