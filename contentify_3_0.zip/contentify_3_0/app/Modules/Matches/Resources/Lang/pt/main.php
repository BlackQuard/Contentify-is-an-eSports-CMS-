<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'broadcast'     => 'Transmissão',
    'left_team'     => 'Equipe da casa',
    'right_team'    => 'Equipe visitante',
    'left_lineup'   => 'Alinhamento da equipe local',
    'right_lineup'  => 'Alinhamento da equipe de visitantes',
    'played_at'     => 'Jogado em',
    'score'         => 'Pontuação',
    'vs'            => 'vs',

];
