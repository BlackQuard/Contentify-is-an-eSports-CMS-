<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'broadcast'     => 'Broadcast',
    'left_team'     => 'Heimteam',
    'right_team'    => 'Gastteam',
    'left_lineup'   => 'Heimteam-Aufstellung',
    'right_lineup'  => 'Gastteam-Lineup',
    'played_at'     => 'Gespielt Am',
    'score'         => 'Ergebnis',
    'vs'            => 'vs',

];
