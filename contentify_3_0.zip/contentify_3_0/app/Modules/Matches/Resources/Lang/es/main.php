<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'broadcast'     => 'Emisión',
    'left_team'     => 'Equipo local',
    'right_team'    => 'Equipo visitante',
    'left_lineup'   => 'Alineación equipo local',
    'right_lineup'  => 'Alineación equipo visitante',
    'played_at'     => 'Jugado el',
    'score'         => 'Puntuación',
    'vs'            => 'vs',

];
