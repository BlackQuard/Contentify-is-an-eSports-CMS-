<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'broadcast'     => 'Stream',
    'left_team'     => 'Equipe',
    'right_team'    => 'Adversaire',
    'left_lineup'   => 'Composition',
    'right_lineup'  => 'Composition adversaire',
    'played_at'     => 'Joué a',
    'score'         => 'Score',
    'vs'            => 'vs',

];
