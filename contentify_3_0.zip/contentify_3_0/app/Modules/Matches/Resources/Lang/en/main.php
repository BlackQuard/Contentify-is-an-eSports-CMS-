<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'broadcast'     => 'Broadcast',
    'left_team'     => 'Home Team',
    'right_team'    => 'Visiting Team',
    'left_lineup'   => 'Home Team Lineup',
    'right_lineup'  => 'Visiting Team Lineup',
    'played_at'     => 'Played At',
    'score'         => 'Score',
    'vs'            => 'vs',

];
