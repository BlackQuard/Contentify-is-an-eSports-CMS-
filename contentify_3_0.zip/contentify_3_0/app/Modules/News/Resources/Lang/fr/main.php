<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'summary'       => 'Summary',
    'written_by'    => 'écrit par',
    'in'            => 'dans', // in category
    'publish_at'    => 'Publié à', // in category
    'rss_last'      => '20 Dernières news',

];
