<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'summary'       => 'Summary',
    'written_by'    => 'written by',
    'in'            => 'in', // in category
    'publish_at'    => 'Publish at', // in category
    'rss_last'      => 'Last 20 News',

];
