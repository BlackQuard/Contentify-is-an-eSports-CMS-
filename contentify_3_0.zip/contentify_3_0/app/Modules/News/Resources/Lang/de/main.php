<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'summary'       => 'Zusammenfassung',
    'written_by'    => 'verfasst von',
    'in'            => 'in', // in category
    'publish_at'    => 'Veröffentlichen um', // in category
    'rss_last'      => 'Die Letzten 20 News',

];
