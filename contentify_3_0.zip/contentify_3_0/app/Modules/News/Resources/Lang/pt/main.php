<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'summary'       => 'Sumário',
    'written_by'    => 'escrito por',
    'in'            => 'em', // in category
    'publish_at'    => 'Postado em', // in category
    'rss_last'      => 'Últimas 20 notícias',

];
