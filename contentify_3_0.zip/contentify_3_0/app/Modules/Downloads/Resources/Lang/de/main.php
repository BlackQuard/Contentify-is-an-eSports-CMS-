<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'download_counter'  => 'Downloads',
    'traffic'           => 'Traffic',
    'perform_download'  => 'Herunterladen',

];
