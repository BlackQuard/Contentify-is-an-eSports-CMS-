<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'download_counter'  => 'Descargas',
    'traffic'           => 'Tráfego',
    'perform_download'  => 'Descarga',

];
