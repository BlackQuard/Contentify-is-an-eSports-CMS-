<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'receiver'      => 'Destinataire',
    'message_sent'  => 'Votre message a été envoyé.',
    're'            => 'Re: ',
    'system_info'   => 'Ce message a été créé automatiquement.',

];
