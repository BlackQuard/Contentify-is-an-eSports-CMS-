<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'receiver'      => 'Receptor',
    'message_sent'  => 'Sua mensagem foi enviada.',
    're'            => 'Re: ',
    'system_info'   => 'Esta mensagem foi criada automaticamente..',

];
