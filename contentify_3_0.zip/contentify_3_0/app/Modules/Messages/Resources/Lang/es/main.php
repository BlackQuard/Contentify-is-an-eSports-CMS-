<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'receiver'      => 'Receptor',
    'message_sent'  => 'Tu mensaje ha sido enviado.',
    're'            => 'Re: ',
    'system_info'   => 'Este mensaje se ha creado automáticamente.',

];
