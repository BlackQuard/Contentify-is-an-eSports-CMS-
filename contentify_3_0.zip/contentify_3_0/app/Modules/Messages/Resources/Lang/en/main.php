<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'receiver'      => 'Receiver',
    'message_sent'  => 'Your message has been sent.',
    're'            => 'Re: ',
    'system_info'   => 'This message has been created automatically.',

];
