<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'receiver'      => 'Empfänger',
    'message_sent'  => 'Ihre Nachricht wurde gesendet.',
    're'            => 'Re: ',
    'system_info'   => 'Diese Nachricht wurde automatisch erstellt.',

];
