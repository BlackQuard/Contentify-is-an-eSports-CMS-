<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'installation'  => 'Installation Module',
    'fail'          => 'Erreur: Impossible d\'installer le module.',
    'success'       => 'Installation du module terminé.'

];
