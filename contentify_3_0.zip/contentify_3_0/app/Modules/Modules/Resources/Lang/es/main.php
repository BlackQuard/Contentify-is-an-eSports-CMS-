<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'installation'  => 'Instalación de módulos',
    'fail'          => 'Error: La instalación del módulo ha fallado.',
    'success'       => 'Instalación del módulo completada.'

];
