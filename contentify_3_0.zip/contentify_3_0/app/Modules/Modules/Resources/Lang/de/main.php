<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'installation'  => 'Modul-Installation',
    'fail'          => 'Fehler: Modul-Installation fehlgeschlagen.',
    'success'       => 'Modul-Installation abgeschlossen.'

];
