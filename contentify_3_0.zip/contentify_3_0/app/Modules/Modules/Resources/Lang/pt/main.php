<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'installation'  => 'Instalação do módulo',
    'fail'          => 'Erro: falha na instalação do módulo.',
    'success'       => 'Instalação do módulo concluída.'

];
