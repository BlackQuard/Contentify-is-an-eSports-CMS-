<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'installation'  => 'Module Installation',
    'fail'          => 'Error: Module installation failed.',
    'success'       => 'Module installation complete.'

];
