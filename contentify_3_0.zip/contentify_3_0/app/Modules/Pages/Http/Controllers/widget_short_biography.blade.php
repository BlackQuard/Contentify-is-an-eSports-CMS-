<div class="widget widget-short-biography">
    {!! $shortBiography !!}
</div>
