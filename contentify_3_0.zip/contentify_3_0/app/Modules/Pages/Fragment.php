<?php

namespace App\Modules\Pages;

class Fragment extends Page
{

    protected $isSubclass = true;

    protected $subclassId = 3;
}