<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'results_type'  => 'Results of type',
    'no_results'    => 'No results found. Please check for typos or try another term.',

];
