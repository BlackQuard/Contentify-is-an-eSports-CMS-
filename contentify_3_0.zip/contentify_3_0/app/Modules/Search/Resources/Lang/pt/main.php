<?php 

return array(

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'results_type'  => 'Resultados do tipo ',
    'no_results'    => 'Não foram encontrados resultados. Verifique erros de digitação ou tente outro termo',

);
