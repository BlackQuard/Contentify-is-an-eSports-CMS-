<?php 

return array(

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'results_type'  => 'Resultados del tipo',
    'no_results'    => 'No se han encontrado resultados. Por favor, compruebe si hay errores tipográficos o pruebe con otro término.',

);
