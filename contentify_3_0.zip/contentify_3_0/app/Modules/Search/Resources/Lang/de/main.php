<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'results_type'  => 'Ergebnisse vom Typ',
    'no_results'    => 'Keine Ergebnisse gefunden. Bitte auf Tippfehler prüfen oder einen anderen Begriff versuchen.',
];
