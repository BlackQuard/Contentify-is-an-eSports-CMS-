<?php 

return [

    /*
    |--------------------------------------------------------------------------
    | Module Language Lines
    |--------------------------------------------------------------------------
    |
    | This file keeps the language lines of the related module.
    |
    */
   
    'results_type'  => 'Résultats de type',
    'no_results'    => 'Aucun résultat trouvé. Veuillez vérifier s\'il y a des fautes de frappe ou essayer un autre terme.',

];
